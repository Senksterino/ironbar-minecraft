package gg.melty.ironbarkmc;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Stream;

/** Finds the player's own Ironbark Lookout install (Steam). Nothing of the game is copied. */
public final class IronbarkLocator {
    private IronbarkLocator() {}

    public static Optional<Path> find() {
        String env = System.getenv("IRONBARK_DIR");
        if (env != null && Files.isDirectory(Path.of(env))) return Optional.of(Path.of(env));

        List<Path> steamRoots = new ArrayList<>();
        for (String p : new String[] {
                "C:/Program Files (x86)/Steam", "C:/Program Files/Steam",
                System.getProperty("user.home") + "/.steam/steam",
                System.getProperty("user.home") + "/.local/share/Steam",
                System.getProperty("user.home") + "/Library/Application Support/Steam" }) {
            Path path = Path.of(p);
            if (Files.isDirectory(path)) steamRoots.add(path);
        }

        Set<Path> libraries = new LinkedHashSet<>(steamRoots);
        Pattern pathLine = Pattern.compile("\"path\"\\s+\"([^\"]+)\"");
        for (Path root : steamRoots) {
            Path vdf = root.resolve("steamapps/libraryfolders.vdf");
            if (!Files.isRegularFile(vdf)) continue;
            try {
                for (String line : Files.readAllLines(vdf)) {
                    Matcher m = pathLine.matcher(line);
                    if (m.find()) libraries.add(Path.of(m.group(1).replace("\\\\", "/")));
                }
            } catch (IOException ignored) {}
        }

        for (Path lib : libraries) {
            Path common = lib.resolve("steamapps/common");
            if (!Files.isDirectory(common)) continue;
            try (Stream<Path> s = Files.list(common)) {
                Optional<Path> hit = s.filter(Files::isDirectory)
                        .filter(d -> d.getFileName().toString().toLowerCase(Locale.ROOT).contains("ironbark"))
                        .findFirst();
                if (hit.isPresent()) return hit;
            } catch (IOException ignored) {}
        }
        return Optional.empty();
    }

    /** Logs candidate audio containers so we can see what is readable. Unity usually packs audio in .fsb/.resS/.bank files. */
    public static void probeAudio(Path dir) {
        int count = 0;
        try (Stream<Path> s = Files.walk(dir, 6)) {
            for (Path p : (Iterable<Path>) s::iterator) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (n.endsWith(".ogg") || n.endsWith(".wav") || n.endsWith(".fsb") || n.endsWith(".bank") || n.endsWith(".ress")) {
                    if (count++ < 40) IronbarkMod.LOG.info("[ironbark] audio candidate: {}", dir.relativize(p));
                }
            }
        } catch (IOException e) {
            IronbarkMod.LOG.warn("[ironbark] audio probe failed: {}", e.toString());
        }
        IronbarkMod.LOG.info("[ironbark] audio candidates found: {}", count);
    }
}
