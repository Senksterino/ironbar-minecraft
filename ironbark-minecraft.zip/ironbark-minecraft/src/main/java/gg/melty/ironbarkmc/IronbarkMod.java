package gg.melty.ironbarkmc;

import java.nio.file.Path;
import java.util.Optional;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IronbarkMod implements ModInitializer {
    public static final String ID = "ironbarkmc";
    public static final Logger LOG = LoggerFactory.getLogger(ID);
    private static final String TAG = "ironbark_spawned";

    private static Optional<Path> ironbarkDir = Optional.empty();
    private static BlockPos towerBase;

    @Override
    public void onInitialize() {
        ironbarkDir = IronbarkLocator.find();
        ironbarkDir.ifPresentOrElse(
                d -> { LOG.info("[ironbark] found Ironbark Lookout at {}", d); IronbarkLocator.probeAudio(d); },
                () -> LOG.warn("[ironbark] Ironbark Lookout not found"));

        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            ServerWorld w = server.getOverworld();
            BlockPos spawn = w.getSpawnPos();
            int ground = w.getTopY(Heightmap.Type.WORLD_SURFACE, spawn.getX(), spawn.getZ());
            towerBase = new BlockPos(spawn.getX(), ground, spawn.getZ());
            if (!TowerBuilder.alreadyBuilt(w, towerBase)) TowerBuilder.build(w, towerBase);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.getPlayer();
            if (towerBase == null) return;
            if (ironbarkDir.isEmpty()) {
                p.sendMessage(Text.literal("Ironbark Lookout isn't installed on this PC (Steam), so its content can't load."), false);
            }
            if (p.getCommandTags().contains(TAG)) return;
            p.addCommandTag(TAG);
            p.teleport(server.getOverworld(), towerBase.getX() + 0.5, towerBase.getY() + 9, towerBase.getZ() + 0.5, 90f, 0f);
            p.giveItemStack(new ItemStack(Items.WOODEN_AXE));
            p.giveItemStack(new ItemStack(Items.WOODEN_PICKAXE));
            p.giveItemStack(new ItemStack(Items.BREAD, 8));
            p.giveItemStack(new ItemStack(Items.TORCH, 8));
        });
    }
}
