package gg.melty.ironbarkmc;

import com.google.gson.*;
import java.io.InputStreamReader;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/** Builds the tower from the rows in tower.json. The sheet is the source of truth. */
public final class TowerBuilder {
    private TowerBuilder() {}

    record Row(String id, int y1, int y2, String mode, int half, int dx, int dz, String block) {}

    private static List<Row> rows;

    private static int i(JsonObject o, String k, int d) { return o.has(k) ? o.get(k).getAsInt() : d; }

    public static List<Row> rows() {
        if (rows != null) return rows;
        List<Row> out = new ArrayList<>();
        try (var in = TowerBuilder.class.getResourceAsStream("/data/ironbarkmc/tower.json")) {
            JsonObject root = JsonParser.parseReader(new InputStreamReader(in)).getAsJsonObject();
            for (JsonElement e : root.getAsJsonArray("rows")) {
                JsonObject o = e.getAsJsonObject();
                out.add(new Row(o.get("id").getAsString(), i(o, "y1", 0), i(o, "y2", 0), o.get("mode").getAsString(),
                        i(o, "half", 0), i(o, "dx", 0), i(o, "dz", 0), o.get("block").getAsString()));
            }
        } catch (Exception ex) {
            IronbarkMod.LOG.error("[ironbark] could not read tower.json", ex);
        }
        return rows = out;
    }

    public static boolean alreadyBuilt(ServerWorld w, BlockPos base) {
        return w.getBlockState(base.up(8)).isOf(Blocks.SPRUCE_PLANKS);
    }

    public static void build(ServerWorld w, BlockPos base) {
        for (Row r : rows()) {
            Identifier id = Identifier.tryParse(r.block());
            if (id == null || !Registries.BLOCK.containsId(id)) {
                IronbarkMod.LOG.warn("[ironbark] row '{}' has unknown block {}", r.id(), r.block());
                continue;
            }
            BlockState st = Registries.BLOCK.get(id).getDefaultState();
            for (int y = r.y1(); y <= r.y2(); y++) {
                switch (r.mode()) {
                    case "fill" -> { for (int x = -r.half(); x <= r.half(); x++) for (int z = -r.half(); z <= r.half(); z++) set(w, base, x, y, z, st); }
                    case "ring" -> { for (int x = -r.half(); x <= r.half(); x++) for (int z = -r.half(); z <= r.half(); z++)
                        if (Math.abs(x) == r.half() || Math.abs(z) == r.half()) set(w, base, x, y, z, st); }
                    case "corners" -> { for (int sx : new int[] {-1, 1}) for (int sz : new int[] {-1, 1}) set(w, base, sx * r.half(), y, sz * r.half(), st); }
                    case "column" -> set(w, base, r.dx(), y, r.dz(), st);
                    default -> IronbarkMod.LOG.warn("[ironbark] row '{}' has unknown mode {}", r.id(), r.mode());
                }
            }
        }
    }

    private static void set(ServerWorld w, BlockPos base, int x, int y, int z, BlockState st) {
        w.setBlockState(base.add(x, y, z), st, Block.NOTIFY_LISTENERS);
    }
}
