# Ironbark Lookout x Minecraft (v0.1, UNTESTED)

Fabric mod for Minecraft: Java Edition 1.21.1. Steve spawns in a fire lookout tower.

**Status: written but never compiled or run.** Version numbers in gradle.properties are unverified.

Works now (in theory): finds the player's Steam copy of Ironbark Lookout, shows an in-game message if missing,
builds a tower from `tower.json`, spawns the player inside with a starter kit, logs possible audio files.

**Not done:**
- The tower in `tower.json` is a PLACEHOLDER shape, not read from Ironbark. Replace with real extracted data.
- Ironbark's audio/model files are not actually read or played yet (Unity formats need a parser).
- No Melty recipe, Prism instance package, screenshot or listing yet.

Build: push to GitHub; the Actions workflow produces the jar. Or run `gradle build` with Java 21.
